<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "zoomanagement";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$E_ID = $_POST["E_ID"];
$E_NAME = $_POST["E_NAME"];
$PHONE = $_POST["PHONE"];
$GENDER = $_POST["GENDER"];
$D_ID = $_POST["D_ID"];

$sql = "INSERT INTO employee (E_ID, E_NAME, PHONE, GENDER, D_ID)
VALUES ('$E_ID', '$E_NAME', '$PHONE', '$GENDER','$D_ID')";

if ($conn->query($sql)=== TRUE) {
    header("Location: add.html");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>