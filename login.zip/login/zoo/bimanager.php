<?php

$user = 'root';
$password = '';
$database = 'zoomanagement';
$servername='localhost';
$mysqli = new mysqli($servername,$user, $password,$database);

if ($mysqli->connect_error) {
	die('Connect Error (' .
	$mysqli->connect_errno . ') '.
	$mysqli->connect_error);
}

$sql = " SELECT * FROM employee WHERE D_ID='D03' ORDER BY E_ID DESC ";
$result = $mysqli->query($sql);
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAMMAL DEPARTMENT</title>
    <link rel="stylesheet" href="manager.css">
</head>
<body>
    <div class="center1">
		<h2>EMPLOYEE DETAILS</h2>
		<table>
			<tr>
					<th>EMPLOYEE_ID</th>
					<th>NAME</th>
					<th>PHONE</th>
					<th>GENDER</th>
			</tr>
            <?php
			while($rows=$result->fetch_assoc())
					{
				?>
			<tr>
				<td><?php echo $rows['E_ID'];?></td>
				<td><?php echo $rows['E_NAME'];?></td>
                <td><?php echo $rows['PHONE'];?></td>
				<td><?php echo $rows['GENDER'];?></td>
			</tr>
            <?php
					}
				?>
        </table>
    </div>
    <div class="container">
        <a href="employee\add.html"><button class="btn btn1">ADD</button></a>
        <a href="employee\empupdel.html"><button class="btn btn1">DELETE/UPDATE</button></a>
    </div>
    <!DOCTYPE html>

    <?php
	
	$sql = " SELECT * FROM todo WHERE D_ID='D03' ORDER BY TASK_NO DESC ";
	$result = $mysqli->query($sql);
// 	$mysqli->close();
?>
<html lang="en">
	<body>
	<a href="\login\first.html"><button class="btn btn1">logout</button></a>
		<section>
			<h2>To do list</h2>
			<table>
				<tr>
					<th>task number</th>
					<th>tasks</th>
				</tr>
				<?php
					while($rows=$result->fetch_assoc())
					{
				?>
				<tr>
					<td><?php echo $rows['TASK_NO'];?></td>
					<td><?php echo $rows['TASK'];?></td>
				</tr>
				
				<?php
					}
				?>
			</table>
		</section>
        <div class="container01">
                <a href="todo/add.html"><button class=" btn btn1">ADD</button></a>
                <a href="todo/todo.html"><button class="btn btn1">DELETE</button></a>
            </div>
	</body>
</html>

<?php
	
	$sql = " SELECT * FROM species WHERE D_ID='D03' ORDER BY S_ID DESC ";
	$result = $mysqli->query($sql);
	// $mysqli->close();
?>
<html lang="en">
	<body>
		<section>
			<h2>species list</h2>
			<table>
				<tr>
					<th>Specie_number</th>
					<th>Specie_name</th>
					<th>Cage_number</th>
					<th>Age</th>
					<th>Gender</th>
				</tr>
				<?php
					while($rows=$result->fetch_assoc())
					{
				?>
				<tr>
					<td><?php echo $rows['S_ID'];?></td>
					<td><?php echo $rows['S_NAME'];?></td>
					<td><?php echo $rows['CAGE_NO'];?></td>
					<td><?php echo $rows['AGE'];?></td>
					<td><?php echo $rows['GENDER'];?></td>
				</tr>
				
				<?php
					}
				?>
			</table>
		</section>
        <div class="container01">
                <a href="species/add.html"><button class=" btn btn1">ADD</button></a>
                <a href="species/speupdel.html"><button class="btn btn1">UPDATE/DELETE</button></a>
            </div>
	</body>
</html>

<?php
	
	$sql = " SELECT * FROM food WHERE E_ID='e105' ORDER BY FOOD_ID DESC ";
	$result = $mysqli->query($sql);
	$mysqli->close();
?>
<html lang="en">
	<body>
		<section>
			<h2>food list</h2>
			<table>
				<tr>
					<th>Food_id</th>
					<th>Food_name</th>
					<th>Quantity</th>
				</tr>
				<?php
					while($rows=$result->fetch_assoc())
					{
				?>
				<tr>
					<td><?php echo $rows['FOOD_ID'];?></td>
					<td><?php echo $rows['FOOD_TYPE'];?></td>
					<td><?php echo $rows['QUANTITY'];?></td>
				</tr>
				
				<?php
					}
				?>
			</table>
		</section>
        <div class="container01">
                <a href="food/add.html"><button class=" btn btn1">ADD</button></a>
                <a href="food/FOOD.html"><button class="btn btn1">UPDATE/DELETE</button></a>
            </div>
	</body>
</html>