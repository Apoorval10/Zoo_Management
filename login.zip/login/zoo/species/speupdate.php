<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "zoomanagement";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$S_ID = $_POST["S_ID"];
$S_NAME = $_POST["S_NAME"];
$CAGE_NO = $_POST["CAGE_NO"];
$AGE = $_POST["AGE"];
$GENDER = $_POST["GENDER"];

$sql = "UPDATE species SET S_NAME='$S_NAME', CAGE_NO='$CAGE_NO', AGE='$AGE', GENDER='$GENDER' WHERE S_ID='$S_ID'";

if ($conn->query($sql)=== TRUE) {
    header("Location: speupdel.html");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>