<?php

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "zoomanagement";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from the form
$FOOD_ID = $_POST["FOOD_ID"];
$S_ID =  $_POST["S_ID"];

$sql = "INSERT INTO consumes (FOOD_ID, S_ID)
VALUES ('$FOOD_ID', '$S_ID')";

if ($conn->query($sql)=== TRUE) {
    header("Location: addcon.html");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>